import java.text.DecimalFormat;

public class GameStats {
	protected long period; // period between drawing in _nanosecs_

	// used for gathering statistics
	private long statsInterval = 0L; // in ns
	private long prevStatsTime;
	private long totalElapsedTime = 0L;
	private long gameStartTime;
	protected int timeSpentInGame = 0; // in seconds

	private long frameCount = 0;
	private double fpsStore[];
	private long statsCount = 0;
	protected double averageFPS = 0.0;

	private long framesSkipped = 0L;
	private long totalFramesSkipped = 0L;
	private double upsStore[];
	protected double averageUPS = 0.0;
	private DecimalFormat df = new DecimalFormat("0.##"); // 2 dp
	
	public GameStats() {
		
	}
	
	
}
