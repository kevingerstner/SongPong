import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

public class BallSimple {
	
	Color ball_color;
	Ellipse2D ball_shape;
	private float size = 30;
	
	public BallSimple(Color c) {
		ball_color = c;
		ball_shape = new Ellipse2D.Float(500, 500, size, size);
	}
	
	synchronized public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(ball_color);
		g2.fill(ball_shape);
	}

}
