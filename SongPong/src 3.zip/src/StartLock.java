
public class StartLock {
	private boolean startLock = false;
	
}
