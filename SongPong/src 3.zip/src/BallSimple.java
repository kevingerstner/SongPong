import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.text.DecimalFormat;
import java.util.Vector;

public class BallSimple extends Ball{
	
	// CONSTANTS
	private DecimalFormat df = new DecimalFormat("0.###");  // 3 dp
	
	// ATTRIBUTES
	Color ballColor;

	public BallSimple(SongMap song, double spawnTime, int size, int[] pos, float speed, Color c, int num) {
		
		super(song, spawnTime, size, pos, speed, num);
		
		// ATTRIBUTES
		ballColor = c;
	}
	
	private boolean first = true;
	
	synchronized public void drawBall(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		
		// ATTRIBUTES
		g2.setColor(ballColor);
		
		// MOTION
		super.drawBall(g);
	}
	
	private void debugMovement() {
		System.out.println("---------------------------------");
		System.out.println("TIME: " + totalTime);
		//System.out.println("FORCE: " + force[1]);
		//System.out.println("ACCELERATION: " + acceleration[1]);
		System.out.println("VELOCITY: " + velocity[1]);
		System.out.println("POSITION: " + position[1]);
		System.out.println("---------------------------------");
		
		if(position[1] > 1050 && first) {
			System.out.println("Actual Time to drop:" + df.format(totalTime));
			System.out.println("+++++++++++++++++++++++++++++++++++++");
			first = false;
		}
	}
	
}
