
public class ParadiseColdplay extends SongMap{

	public ParadiseColdplay(SongPong game, String songName, int delay) {
		super(game, songName, delay);
		// TODO Auto-generated constructor stub
	}
	
}
