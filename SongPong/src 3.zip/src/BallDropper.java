import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;

public class BallDropper {

	// REFERENCES
	private SongMap song;
	private GameStats stats;
	private Paddle paddle;
	private MusicPlayer player;
	private DecimalFormat df = new DecimalFormat("0.##"); // 2 dp
	
	// CONSTANTS
	final static int NUM_COL = 16;
	protected final static float GRAVITY_C = 9.8f;
	final static int START_POS_Y = -2 * Ball.BALL_SIZE; //NOTE: START_POS_Y = 0 means that the top of the ball is at y = 0
	
	// SCREEN INFO
	protected int screenW;
	protected int screenH;
	private int screenPadding;
	private int effScreenW;
	private int[] ballCols;
	protected boolean showBallColumns = true;
	
	// BALLS
	private int ballCounter = 0;
	private int dropIndex = 0;
	private ArrayList<Ball> ballList = new ArrayList<Ball>(); // list of balls to drop
	private ArrayList<Ball> activeBallList = new ArrayList<Ball>(); //stores all balls currently spawned
	private ArrayList<Ball> finishedBallList = new ArrayList<Ball>(); //stores all missed balls
	
	// TIME
	protected double dropTime;
	protected double delayTime;
	protected double lagShift = 0.25; // Don't know where this lag is coming from

	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	CONSTRUCTOR
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public BallDropper(SongMap g) {
		song = g;
		stats = song.gs;
		paddle = song.myPaddle;
		delayTime = song.delayTimeSec;
		player = song.tuneSpinner;
		
		screenW = song.screenW;
		screenH = song.screenH;
		
		calcColumns();
		dropTime = calcDropTime(START_POS_Y, paddle.getPaddleTopY());
		System.out.println("+++++++++++++++++++++++++++++++++++++");
		System.out.println("Expected Ball Drop Time: " + df.format(dropTime) + " seconds");
		System.out.println("+++++++++++++++++++++++++++++++++++++");
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	SPAWN
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void spawnBall(double hitTime, int column) {
		// ATTRIBUTES
		int startPosX = ballCols[column] - (Ball.BALL_SIZE / 2);
		int[] pos = {startPosX, START_POS_Y};
		Color c = Color.red;
		
		// TIME
		// hitTime: desired time, in seconds, the ball should hit
		// delayTime: time to wait before dropping
		// dropTime: time it takes for the ball to fall
		double adjustedTime = hitTime + delayTime - dropTime;
		
		// CREATE
		BallSimple simp = new BallSimple(song, adjustedTime, Ball.BALL_SIZE, pos, Ball.BALL_SPEED, c, ballCounter+1);
		ballCounter++;
		ballList.add(simp);
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	GAME CONTROLS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void purgeBalls() {	
		
		for(Ball b : activeBallList) {
			finishedBallList.add(b);
		}
	}
	
	public void stopBalls() {
		for(Ball ball : activeBallList) {
			ball.stopMoving();
		}
	}
	
	public void rewindBalls() {
		double currentTime = stats.getTimeElapsed();
		System.out.println("yahhhh it's rewind time " + currentTime);
		for(int i = dropIndex; i > 0; i--) {
			Ball ball = ballList.get(i);
			if(ball.spawnTime > currentTime) {
				System.out.println("Rewind ball with time: " + ball.spawnTime);
				finishedBallList.remove(ball);
				ball.moveBallToSpawnLoc();
				dropIndex--;
			}
		}
		activeBallList.clear();
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	DROPPER
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void checkDrop() {
		double currentTime = stats.getTimeElapsed();
		//System.out.println("CHECK DROP @ t = " + currentTime);
		
		if(dropIndex < ballList.size()) {
			Ball b = ballList.get(dropIndex);
			
			while(b.spawnTime <= currentTime) {
				
				// This second condition prevents a ball from spawning if its time has been skipped
				if(b.spawnTime + 0.25 < currentTime) {
					System.out.println("Removed ball with drop time " + df.format(b.spawnTime));
					finishedBallList.add(b);
					dropIndex++;
					break;
				}
				
				System.out.println("BALL " + b.ballNum + "/ SPAWN " + df.format(b.spawnTime) + "s / TIME: " + df.format(stats.getTimeElapsed()));
				
				activeBallList.add(b); //add to the list of spawned balls

				b.isFalling = true;
				dropIndex++;
				
				b = ballList.get(dropIndex);
			}
		}
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	UPDATE
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void updateBalls() {
		for(Ball ball : activeBallList) {
			ball.moveBall();
			if(ball.isFalling) {
				ball.checkCollide();
			}
			if(ball.checkDoneBouncing()) { finishedBallList.add(ball);}
			if(ball.checkMissed()) { finishedBallList.add(ball);}
		}
		
		// Destroy any balls that are caught or missed
		for(Ball rmBall : finishedBallList) {
			activeBallList.remove(rmBall);
		}
	}
	
	public float calcDropTime(int y1, int y2) {
		return (y2 - y1) / Ball.BALL_SPEED;
	}
	
	public double getDropTime() {
		return dropTime;
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	RENDER
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void renderBalls(Graphics g) {
		for(Ball ball : activeBallList) {
			ball.drawBall(g);
		}
	}
	
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	COLUMNS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void calcColumns() {
		
		screenPadding = (int)(screenW * 0.1); // padding is 10% of screen width on each side (20% total)
		effScreenW = screenW - 2 * screenPadding; // the screen width minus the padding
		//System.out.println("ScreenW: " + screenW + "screenPadding: " + screenPadding + " EffScreenWidth: " + effScreenW);
		
		ballCols = new int[NUM_COL+1]; // need n+1 lines to make n columns
		int colStep = effScreenW / NUM_COL; // amount of x to move per column
		
		for(int i = 0; i < NUM_COL+1; i++) {
			ballCols[i] = colStep * i + screenPadding;
			//System.out.println("Column " + i + " is located at x = " + ballCols[i]);
		}
	}
	
	public void displayColumns(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		
		for(int i = 0; i < NUM_COL+1; i++) {
			g.setColor(Color.RED);
			g2.drawLine(ballCols[i], 0, ballCols[i], screenH);
		}
	}
	
	public void toggleBallColumns() {
		if(showBallColumns) showBallColumns = false;
		else showBallColumns = true;
	}
	
	public int[] getColumns() {
		return ballCols;
	}
}
