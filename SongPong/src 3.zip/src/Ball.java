import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

public abstract class Ball {

	// CONSTANTS
	final static float BALL_SPEED = 400;
	final static int BALL_SIZE = 50; // Diameter
	protected final static int BOUNCE_HEIGHT = 100;
	
	protected Paddle paddle;
	protected BallDropper bd;
	protected GameStats gs;
	
	// ATTRIBUTES
	Ellipse2D ball_shape;
	protected int size;
	protected int ballNum;
	Color myColor = Color.red;
	
	// POSITION
	protected int startPosX;
	protected int startPosY;
	protected float[] startPosition = new float[2];
	protected float[] position = new float[2];
	
	// VELOCITY
	protected float[] velocity = new float[2];
	
	// TIME
	protected double spawnTime;
	protected boolean firstUpdate = true;
	protected double totalTime = 0;
	protected long lastTime;
	
	// STATE
	protected boolean isFalling = false;
	protected boolean isCaught = false;
	protected boolean isBouncing = false;
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	DEFAULT CONSTRUCTOR
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public Ball(SongMap song, double spawnTime, int size, int[] pos, float speed, int num) {
		paddle = song.myPaddle;
		this.bd = song.bd;
		this.gs = song.gs;
		ballNum = num;
		
		// POSITION
		startPosition[0] = pos[0];
		startPosition[1] = pos[1];
		System.out.println(startPosition[1]);
		position[0] = startPosition[0];
		position[1] = startPosition[1];
		
		// VELOCITY
		velocity[0] = 0;
		velocity[1] = speed;
		
		// ATTRIBUTES
		ball_shape = new Ellipse2D.Float(startPosX, startPosY, size, size);
		this.size = size;
		
		// TIME
		this.spawnTime = spawnTime;
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	METHODS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	protected void drawBall(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(myColor);
		
		// X : 
		// Y : shifted size down so that y-position is at the bottom of the ball (good for paddle collision)
		g2.fillOval((int)position[0], (int)position[1]-size, size, size);
		g2.setColor(Color.white);
		g2.drawString("" + ballNum, (int)position[0]+(size/2)-5, (int)position[1]-(size/2)+5);
	}
	
	protected boolean checkMissed() {
		return (int)position[1]-size > bd.screenH;
	}
	
	public boolean checkDoneBouncing() {
		return (isCaught && !isBouncing);
	}
	
	public void moveBallToSpawnLoc() {
		position[0] = startPosition[0];
		position[1] = startPosition[1];
		if(this.ballNum == 4) {
			System.out.println("4 POS: " + position[1]);
		}
		isFalling = true;
		isBouncing = false;
		isCaught = false;
		myColor = Color.green;
	}
	
	synchronized public void moveBall() {
		// Ensures velocity starts at 0
		if(firstUpdate) {
			lastTime = System.nanoTime();
			firstUpdate = false;
		}
		
		long startTime = System.nanoTime();
		long elapsedTime = startTime - lastTime;
		double timeStep = (double) elapsedTime / 1_000_000_000; // in seconds
		
		// ---- FALL ------------------------
		
		if(isFalling) {
			if(this.ballNum == 4) {
				System.out.println("4 FALLING");
			}
			position[1] += (velocity[1] * timeStep); // update position
		}
		
		// ---- BOUNCE ----------------------
		if(isBouncing) {
			//System.out.println("BOUNCING");
			if(position[1] > paddle.getPaddleY() - BOUNCE_HEIGHT) {
				position[1] -= (velocity[1] * timeStep);
			}
			else {
				//System.out.println("BOUNCE DONE");
				isBouncing = false;
			}
		}
		
		// ---- END -------------------------
		lastTime = startTime;
		totalTime += timeStep;
	}
	
	synchronized public void stopMoving() {
		firstUpdate = true;
	}
	
	public boolean checkCollide() {
		//DETECT
		boolean collided = paddle.checkCatchBall((int)position[0], (int)position[1], size);
		
		//ACTION
		if(collided) {
			//System.out.println("CAUGHT @ " + gs.getTimeElapsed());
			isFalling = false;
			isCaught = true;
			isBouncing = true;
			myColor = Color.blue;
		}
		return collided;
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	GETTERS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public double getSpawnTime() { return spawnTime; }
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	SETTERS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void skipSeconds(double sec) {
		spawnTime -= sec;
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	ABSTRACT CLASSES
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
}
