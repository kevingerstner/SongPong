import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.text.DecimalFormat;
import java.util.Vector;

public class BallSimple extends Ball{
	
	// CONSTANTS
	private DecimalFormat df = new DecimalFormat("0.###");  // 3 dp
	
	// ATTRIBUTES
	Color ballColor;

	public BallSimple(BallDropper bd, Paddle p, double spawnTime, int size, int[] pos, float speed, Color c) {
		
		super(bd, p, spawnTime, size, pos, speed);
		
		// ATTRIBUTES
		ballColor = c;
	}
	
	private boolean first = true;
	
	synchronized public void moveBall() {
		
		// Ensures velocity starts at 0
		if(firstUpdate) {
			lastTime = System.nanoTime();
			firstUpdate = false;
		}
		
		long startTime = System.nanoTime();
		long elapsedTime = startTime - lastTime;
		double timeStep = (double) elapsedTime / 1_000_000_000; // in seconds
		
		// If the ball is falling
		if(isFalling) {
			//System.out.println("FALLING");
			position[1] += (velocity[1] * timeStep); // update position

		}
		
		if(isBouncing) {
			//System.out.println("BOUNCING");
			if(position[1] > paddle.getPaddleY() - BOUNCE_HEIGHT) {
				position[1] -= (velocity[1] * timeStep);
			}
			else {
				System.out.println("BOUNCE DONE");
				isBouncing = false;
			}
		}
		
		lastTime = startTime;
		totalTime += timeStep;
	}
	
	public boolean checkCollide() {
		//DETECT
		boolean collided = paddle.checkCatchBall((int)position[0], (int)position[1]);
		
		//ACTION
		if(collided) {
			isFalling = false;
			isCaught = true;
			isBouncing = true;
			myColor = Color.blue;
		}
		return collided;
	}
	
	synchronized public void drawBall(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		
		// ATTRIBUTES
		g2.setColor(ballColor);
		
		// MOTION
		super.drawBall(g);
	}
	
	private void debugMovement() {
		System.out.println("---------------------------------");
		System.out.println("TIME: " + totalTime);
		//System.out.println("FORCE: " + force[1]);
		//System.out.println("ACCELERATION: " + acceleration[1]);
		System.out.println("VELOCITY: " + velocity[1]);
		System.out.println("POSITION: " + position[1]);
		System.out.println("---------------------------------");
		
		if(position[1] > 1050 && first) {
			System.out.println("Actual Time to drop:" + df.format(totalTime));
			System.out.println("+++++++++++++++++++++++++++++++++++++");
			first = false;
		}
	}
	
}
