import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

public abstract class Ball {

	// CONSTANTS
	final static float BALL_SPEED = 400;
	protected final static int BOUNCE_HEIGHT = 100;
	
	protected Paddle paddle;
	protected BallDropper bd;
	
	// ATTRIBUTES
	Ellipse2D ball_shape;
	protected int size;
	Color myColor = Color.red;
	
	// POSITION
	protected int startPosX;
	protected int startPosY;
	protected float[] startPosition = new float[2];
	protected float[] position = new float[2];
	
	// VELOCITY
	protected float[] velocity = new float[2];
	
	// TIME
	protected double spawnTime;
	protected boolean firstUpdate = true;
	protected double totalTime = 0;
	protected long lastTime;
	
	// STATE
	protected boolean isFalling = false;
	protected boolean isCaught = false;
	protected boolean isBouncing = false;
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	DEFAULT CONSTRUCTOR
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public Ball(BallDropper bd, Paddle p, double spawnTime, int size, int[] pos, float speed) {
		paddle = p;
		this.bd = bd;
		
		// POSITION
		startPosition[0] = pos[0];
		startPosition[1] = pos[1];
		position = startPosition;
		
		// VELOCITY
		velocity[0] = 0;
		velocity[1] = speed;
		
		// ATTRIBUTES
		ball_shape = new Ellipse2D.Float(startPosX, startPosY, size, size);
		this.size = size;
		
		// TIME
		this.spawnTime = spawnTime;
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	METHODS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	protected void drawBall(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(myColor);
		g2.fillOval((int)position[0], (int)position[1]-size, size, size);
	}
	
	protected boolean checkMissed() {
		return (int)position[1]-size > bd.screenH;
	}
	
	public boolean checkDoneBouncing() {
		return (isCaught && !isBouncing);
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	GETTERS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public double getSpawnTime() { return spawnTime; }
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	ABSTRACT CLASSES
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	protected abstract void moveBall();
	
	public abstract boolean checkCollide();
	
}
