
public class GameRender implements Runnable {

	GamePanel gp;
	GameStats gs;
	
	private static final int NO_DELAYS_PER_YIELD = 16;
	/*
	 * Number of frames with a delay of 0 ms before the animation thread yields
	 * to other running threads.
	 */
	private static int MAX_FRAME_SKIPS = 5; // was 2;
	// no. of frames that can be skipped in any one animation loop
	// i.e the games state is updated but not rendered
	
	private boolean running = false;
	
	public GameRender(GamePanel gp) {
		this.gp = gp;
		gs = gp.gs;
	}
	
	public void run()
	{
		System.out.println("Running Thread " + Thread.currentThread().getId());

		long previousTime, currentTime, timeDiff, sleepTime;
		long overSleepTime = 0L;
		int noDelays = 0;
		long excess = 0L;

		gs.gameStartTime = System.nanoTime();
		gs.prevStatsTime = gs.gameStartTime;
		previousTime = gs.gameStartTime;
		
		running = true;

		/* The frames of the animation are drawn inside the while loop. */
		while (running) {
			gp.gameUpdate();

			currentTime = System.nanoTime();
			timeDiff = currentTime - previousTime; // also frame time
			sleepTime = (gs.period - timeDiff) - overSleepTime;

			// If this process took shorter than a cycle, sleep
			// If this process took longer than a cycle, yield
			if (sleepTime > 0) { // some time left in this cycle
				try {
					Thread.sleep(sleepTime / 1_000_000L); // nano -> ms
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				overSleepTime = (System.nanoTime() - currentTime) - sleepTime;
			} else { // sleepTime <= 0; the frame took longer than the period
				excess -= sleepTime; // store excess time value
				overSleepTime = 0L;

				if (++noDelays >= NO_DELAYS_PER_YIELD) {
					Thread.yield(); // give another thread a chance to run
					noDelays = 0;
				}
			}

			previousTime = System.nanoTime();

			/*
			 * If frame animation is taking too long, update the game state
			 * without rendering it, to get the updates/sec nearer to the
			 * required FPS.
			 */
			int skips = 0;
			while ((excess > gs.period) && (skips < MAX_FRAME_SKIPS)) {
				excess -= gs.period;
				gp.gameUpdate(); // update state but don't render
				skips++;
			}
			gs.framesSkipped += skips;
			gs.storeStats();
		}
		gp.finishOff();
		System.exit(0); // so window disappears
	} // end of run()
}
