import java.awt.Graphics;

public abstract class SongMap {
	
	protected BallDropper bd;
	
	public SongMap(SongPong game, String songName) {
		bd = game.bd;
		noteMap();
	}
	
	public void renderSongStuff(Graphics g) {
		if(bd.showBallColumns)
	    	bd.displayColumns(g);
		
		// Game Elements
		bd.renderBalls(g);
	}
	
	public void updateSongStuff() {
		bd.checkDrop();
		//bd.updateBalls();
	}
	
	public void showBallColumns() {
		bd.toggleBallColumns();
	}
	
	/**
	 * Make a list of notes for the song
	 */
	protected abstract void noteMap();
}
