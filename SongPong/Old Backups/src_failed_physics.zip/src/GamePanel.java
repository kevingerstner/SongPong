// GameFrame.java
// Roger Mailler, January 2009, adapted from
// 		Andrew Davison, April 2005, ad@fivedots.coe.psu.ac.th

import java.awt.BufferCapabilities;
import java.awt.Color;
import java.awt.DisplayMode;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.ImageCapabilities;
import java.awt.Window;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferStrategy;
import java.text.DecimalFormat;

import javax.swing.JFrame;

public abstract class GamePanel implements Runnable{
	private static final long serialVersionUID = 1863596360846514344L;
	private static final int NUM_BUFFERS = 2; // used for page flipping

	protected GameStats gs;
	
	//NEW
	protected float interpolation;
	JFrame mainFrame;

	protected int pWidth, pHeight; // panel dimensions

	private Thread animator; // the thread that performs the animation
	protected boolean running = false; // used to stop the animation thread
	protected boolean isPaused = false;
	private boolean finishedOff = false;



	// used at game termination
	protected boolean gameOver = false;

	// used for full-screen exclusive mode
	private GraphicsDevice gd;
	private Graphics gScr;
	private BufferStrategy bufferStrategy;
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	CONSTRUCTOR
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/

	public GamePanel(long period) {
		gs = new GameStats(this);
	
		gs.period = period;
		
		initFullScreen();

		readyForTermination();

		simpleInitialize();

		mainFrame.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				mousePress(e.getX(), e.getY());
			}
		});

		mainFrame.addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseMoved(MouseEvent e) {
				mouseMove(e.getX(), e.getY());
			}
		});

		gameStart();

	} // end of GamePanel()

	public void run() {
		screenUpdate();
	}
	
	private void initFullScreen() {
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		gd = ge.getDefaultScreenDevice();
		
		GraphicsConfiguration gc = gd.getDefaultConfiguration();
		mainFrame = new JFrame(gc);
		mainFrame.setUndecorated(true); // no menu bar, borders, etc. or Swing components
		mainFrame.setIgnoreRepaint(true); // turn off all paint events since doing active
		// rendering
		mainFrame.setResizable(false);
		mainFrame.setVisible(true);

		if (!gd.isFullScreenSupported()) {
			System.out.println("Full-screen exclusive mode not supported");
			System.exit(0);
		}
		gd.setFullScreenWindow(mainFrame); // switch on full-screen exclusive mode

		// we can now adjust the display modes, if we wish
		showCurrentMode();

		// setDisplayMode(800, 600, 8); // or try 8 bits
		// setDisplayMode(1280, 1024, 32);

		reportCapabilities();

		pWidth = mainFrame.getBounds().width;
		pHeight = mainFrame.getBounds().height;

		setBufferStrategy();
	} // end of initFullScreen()

	
	private void reportCapabilities() {
		System.out.println("=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=");
		GraphicsConfiguration gc = gd.getDefaultConfiguration();

		// Image Capabilities
		ImageCapabilities imageCaps = gc.getImageCapabilities();
		System.out.println("Image Caps. isAccelerated: "
				+ imageCaps.isAccelerated());
		System.out.println("Image Caps. isTrueVolatile: "
				+ imageCaps.isTrueVolatile());

		// Buffer Capabilities
		BufferCapabilities bufferCaps = gc.getBufferCapabilities();
		System.out.println("Buffer Caps. isPageFlipping: "
				+ bufferCaps.isPageFlipping());
		System.out.println("Buffer Caps. Flip Contents: "
				+ getFlipText(bufferCaps.getFlipContents()));
		System.out.println("Buffer Caps. Full-screen Required: "
				+ bufferCaps.isFullScreenRequired());
		System.out.println("Buffer Caps. MultiBuffers: "
				+ bufferCaps.isMultiBufferAvailable());
		System.out.println("=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=");
	}

	//??????????
	private String getFlipText(BufferCapabilities.FlipContents flip) {
		if (flip == null)
			return "false";
		else if (flip == BufferCapabilities.FlipContents.UNDEFINED)
			return "Undefined";
		else if (flip == BufferCapabilities.FlipContents.BACKGROUND)
			return "Background";
		else if (flip == BufferCapabilities.FlipContents.PRIOR)
			return "Prior";
		else
			// if (flip == BufferCapabilities.FlipContents.COPIED)
			return "Copied";
	}

	private void setBufferStrategy() {
		
		mainFrame.createBufferStrategy(NUM_BUFFERS);
		bufferStrategy = mainFrame.getBufferStrategy(); // store for later
		
	}

/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	QUIT
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	private void readyForTermination() {
		mainFrame.addKeyListener(new KeyAdapter() {
			// listen for esc, q, end, ctrl-c on the canvas to
			// allow a convenient exit from the full screen configuration
			public void keyPressed(KeyEvent e) {
				int keyCode = e.getKeyCode();
				if ((keyCode == KeyEvent.VK_Q)
						|| (keyCode == KeyEvent.VK_END)
						|| ((keyCode == KeyEvent.VK_C) && e.isControlDown())) {
					running = false;
				}
			}
		});

		// for shutdown tasks
		// a shutdown may not only come from the program
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				running = false;
				finishOff();
			}
		});
	} // end of readyForTermination()



/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	GAME STATES
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void resumeGame() {
		isPaused = false;
	}

	public void pauseGame() {
		isPaused = true;
	}

	public void stopGame() {
		running = false;
	}

/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	RUNNABLE
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/

	/**
	 * Starts the animation loop
	 */
	private void gameStart() {
		if (animator == null || !running) {
			animator = new Thread(this); //puts this GameFrame in new Thread
			animator.start(); // calls GameFrame's run method
			
			Thread physThread = new Thread(new GamePhysics(this));
			physThread.start();
			Thread rendThread = new Thread(new GameRender(this));
			rendThread.start();
		}
	}

	/**
	 * Renders to the backbuffer
	 */
	private void gameRender(Graphics gScr) {
		// clear the background
		gScr.setColor(Color.white);
		gScr.fillRect(0, 0, pWidth, pHeight);

		// call Song Pong's render
		simpleRender(gScr);

		if (gameOver)
			gameOverMessage(gScr);
	}

	protected void screenUpdate() {
		// use active rendering
		try {
			gScr = bufferStrategy.getDrawGraphics();
			gameRender(gScr);
			gScr.dispose();
			if (!bufferStrategy.contentsLost())
				bufferStrategy.show();
			else
				System.out.println("Contents Lost");
		} catch (Exception e) {
			e.printStackTrace();
			running = false;
		}
	} // end of screenUpdate()

	/**
	 * Should be update the game state
	 */
	protected void gameUpdate() {
		if (!isPaused && !gameOver)
			simpleUpdate();

	}
	
	protected void updatePhysics() {
		if(!isPaused && !gameOver) {
			physicsUpdate();
		}
	}

	

/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	TERMINATION / CLEANUP METHODS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	/**
	 * finishOff():
	 * Tasks to do before terminating. Called at end of run() and via the
	 * shutdown hook in readyForTermination().
	 * 
	 * The call at the end of run() is not really necessary, but included for
	 * safety. The flag stops the code being called twice.
	 **/
	protected void finishOff(){ 
		// System.out.println("finishOff");
		if (!finishedOff) {
			finishedOff = true;
			gs.printStats();
			restoreScreen();
			System.exit(0);
		}
	}

	/**
	 * restoreScreen():
	 * Switch off full screen mode. This also resets the display mode if it's
	 * been changed.
	 **/
	private void restoreScreen(){
		Window w = gd.getFullScreenWindow();
		if (w != null)
			w.dispose();
		gd.setFullScreenWindow(null);
	}

/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	DISPLAY MODE METHODS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	/**
	 * setDisplayMode(int width, int height, int bitDepth):
	 * Attempt to set the display mode to the given width, height, and bit depth
	 * @param width
	 * @param height
	 * @param bitDepth
	 */
	private void setDisplayMode(int width, int height, int bitDepth) {
		
		if (!gd.isDisplayChangeSupported()) {
			System.out.println("Display mode changing not supported");
			return;
		}

		if (!isDisplayModeAvailable(width, height, bitDepth)) {
			System.out.println("Display mode (" + width + "," + height + ","
					+ bitDepth + ") not available");
			return;
		}

		DisplayMode dm = new DisplayMode(width, height, bitDepth,
				DisplayMode.REFRESH_RATE_UNKNOWN); // any refresh rate
		try {
			gd.setDisplayMode(dm);
			System.out.println("Display mode set to: (" + width + "," + height
					+ "," + bitDepth + ")");
		} catch (IllegalArgumentException e) {
			System.out.println("Error setting Display mode (" + width + ","
					+ height + "," + bitDepth + ")");
		}

		try { // sleep to give time for the display to be changed
			Thread.sleep(1000); // 1 sec
		} catch (InterruptedException ex) {
		}
	}
	/**
	 * isDisplayModeAvailable(int width, int height, int bitDepth)
	 * Check that a displayMode with this width, height, bit depth is available.
	 * We don't care about the refresh rate, which is probably REFRESH_RATE_UNKNOWN anyway.
	 * @param width
	 * @param height
	 * @param bitDepth
	 **/
	private boolean isDisplayModeAvailable(int width, int height, int bitDepth) {
		
		DisplayMode[] modes = gd.getDisplayModes();
		showModes(modes);

		for (int i = 0; i < modes.length; i++) {
			if (width == modes[i].getWidth() && height == modes[i].getHeight()
					&& bitDepth == modes[i].getBitDepth())
				return true;
		}
		return false;
	}
	/**
	 * showModes(DisplayMode[] modes):
	 * Pretty print the display mode information in modes
	 * @param modes
	 **/
	private void showModes(DisplayMode[] modes){
		System.out.println("Modes");
		for (int i = 0; i < modes.length; i++) {
			System.out.print("(" + modes[i].getWidth() + ","
					+ modes[i].getHeight() + "," + modes[i].getBitDepth() + ","
					+ modes[i].getRefreshRate() + ")  ");
			if ((i + 1) % 4 == 0)
				System.out.println();
		}
		System.out.println();
	}
	/**
	 * 	showCurrentMode():
	 *  Print the display mode details for the graphics device
	 */
	private void showCurrentMode(){
		DisplayMode dm = gd.getDisplayMode();
		System.out.println("Current Display Mode: (" + dm.getWidth() + ","
				+ dm.getHeight() + "," + dm.getBitDepth() + ","
				+ dm.getRefreshRate() + ")  ");
	}

/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	ABSTRACT GAME METHODS TO IMPLEMENT
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/

	/**
	 * Should implement game specific rendering
	 * 
	 * @param g
	 */
	protected abstract void simpleRender(Graphics g);

	/**
	 * Should display a game specific game over message
	 * 
	 * @param g
	 */
	protected abstract void gameOverMessage(Graphics g);

	protected abstract void simpleUpdate();
	
	protected abstract void physicsUpdate();

	/**
	 * This just gets called when a click occurs, no default behavior
	 */
	protected abstract void mousePress(int x, int y);

	/**
	 * This just gets called when a click occurs, no default behavior
	 */
	protected abstract void mouseMove(int x, int y);

	/**
	 * Should be overridden to initialize the game specific components
	 */
	protected abstract void simpleInitialize();

} // end of GamePanel class
