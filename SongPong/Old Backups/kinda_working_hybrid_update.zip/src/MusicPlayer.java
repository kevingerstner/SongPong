import java.io.File;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class MusicPlayer {
	
	Clip audioClip;
	long clipTime;

	public void playMusic(String musicLocation) {
		
		try {
			File musicPath = new File(musicLocation);
			
			if(musicPath.exists()) {
				AudioInputStream audioInput = AudioSystem.getAudioInputStream(musicPath);
				audioClip = AudioSystem.getClip();
				audioClip.open(audioInput);
				audioClip.start();
			}
			else {
				System.err.println("No file, bitch.");
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
			System.err.println("Could not play music. RIP.");
		}
	}
	
	public void pauseMusic() {
		clipTime = audioClip.getMicrosecondPosition();
		audioClip.stop();
	}
	
	public void resumeMusic() {
		audioClip.setMicrosecondPosition(clipTime);
		audioClip.start();
	}
}
