import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Iterator;

public class BallDropper {

	// REFERENCES
	private SongPong game;
	private GameStats stats;
	private Paddle paddle;
	
	// CONSTANTS
	final static int NUM_COL = 20;
	final static int BALL_SIZE = 40; // Diameter
	protected final static float GRAVITY_C = 9.8f;
	final static int START_POS_Y = -2 * BALL_SIZE; //NOTE: START_POS_Y = 0 means that the top of the ball is at y = 0
	
	// SCREEN INFO
	protected int screenW;
	protected int screenH;
	private int screenPadding;
	private int effScreenW;
	private int[] ballCols;
	protected boolean showBallColumns = false;
	
	protected double dropTime;
	
	// BALLS
	private ArrayList<Ball> ballList = new ArrayList<Ball>(); // list of balls to drop
	private ArrayList<Ball> activeBallList = new ArrayList<Ball>(); //stores all balls currently spawned
	private ArrayList<Ball> finishedBallList = new ArrayList<Ball>(); //stores all missed balls

	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	CONSTRUCTOR
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public BallDropper(SongPong g) {
		game = g;
		stats = game.gs;
		paddle = game.myPaddle;
		
		screenW = game.pWidth;
		screenH = game.pHeight;
		
		calcColumns();
		dropTime = calcDropTime(START_POS_Y, screenH);
		System.out.println(dropTime);
		System.out.println("+++++++++++++++++++++++++++++++++++++");
		System.out.println("Expected Ball Drop Time: " + dropTime);
		System.out.println("+++++++++++++++++++++++++++++++++++++");
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	DROPPER
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void checkDrop() {
		double currentTime = stats.getTimeElapsed();
		
		if(!ballList.isEmpty()) {
			Ball b = ballList.get(0);
			
			while(b.spawnTime < currentTime) {
				System.out.println("SPAWN BALL");
				activeBallList.add(b); //add to list of spawned balls
				b.isFalling = true;
				ballList.remove(0); // remove from list of balls to spawn
				
				// spawn any more balls with the same time
				if (!ballList.isEmpty()){
					b = ballList.get(0);
				} else {
					break;
				}
			}
		}
		
		//System.out.println(currentTime);
	}
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	BALL STUFF
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void spawnBall(double time, int column) {
		// ATTRIBUTES
		int startPosX = ballCols[column] - (BALL_SIZE / 2);
		int[] pos = {startPosX, START_POS_Y};
		Color c = Color.red;
		
		// INITIAILZE
		double adjustedTime = time - dropTime;
		BallSimple simp = new BallSimple(game, this, paddle, adjustedTime, BALL_SIZE, pos, Ball.BALL_SPEED, c);
		ballList.add(simp);
	}
	
	public void updateBalls() {
	
		for(Ball ball : activeBallList) {
			ball.moveBall();
			ball.checkCollide();
			if(ball.checkDoneBouncing()) { finishedBallList.add(ball);}
			if(ball.checkMissed()) { finishedBallList.add(ball);}
		}
		
		// Destroy any balls that are caught or missed
		for(Ball rmBall : finishedBallList) {
			activeBallList.remove(rmBall);
			rmBall = null;
		}
	}
	
	/**
	 * Render all balls that are currently active.
	 * @param g
	 */
	public void renderBalls(Graphics g) {
		for(Ball ball : activeBallList) {
			ball.drawBall(g);
		}
	}
	
	public float calcDropTime(int y1, int y2) {
		return (y2 - y1) / Ball.BALL_SPEED;
	}
	
	
/* =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
 * 	COLUMNS
 * =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+*/
	
	public void calcColumns() {
		
		screenPadding = (int)(screenW * 0.1); // padding is 10% of screen width on each side (20% total)
		effScreenW = screenW - 2 * screenPadding; // the screen width minus the padding
		//System.out.println("ScreenW: " + screenW + "screenPadding: " + screenPadding + " EffScreenWidth: " + effScreenW);
		
		ballCols = new int[NUM_COL+1]; // need n+1 lines to make n columns
		int colStep = effScreenW / NUM_COL; // amount of x to move per column
		
		for(int i = 0; i < NUM_COL+1; i++) {
			ballCols[i] = colStep * i + screenPadding;
			//System.out.println("Column " + i + " is located at x = " + ballCols[i]);
		}
	}
	
	public void displayColumns(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		
		for(int i = 0; i < NUM_COL+1; i++) {
			g.setColor(Color.RED);
			g2.drawLine(ballCols[i], 0, ballCols[i], screenH);
		}
	}
	
	public void toggleBallColumns() {
		if(showBallColumns) showBallColumns = false;
		else showBallColumns = true;
	}
}
