
public class ParadiseColdplay extends SongMap{

	public ParadiseColdplay(SongPong game, String songName) {
		super(game, songName);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void noteMap() {
		bd.spawnBall(3.0, 3); // time, column
		//bd.spawnBall(4.0, 5); // time, column
	}
}
